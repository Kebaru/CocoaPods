//
//  AuthViewController.swift
//  CocoaPods
//
//  Created by Кардошевский ИСИП 20 on 13.04.2022.
//

import UIKit
import Alamofire
import SwiftyJSON

class AuthViewController: UIViewController {

    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func authAction(_ sender: Any) {
        if !(loginTextField.text!.isEmpty) && !(passwordTextField.text!.isEmpty){
            let login = self.loginTextField.text!
            let password = self.passwordTextField.text!
            let url = "http://mad2019.hakta.pro/api/login/?login=\(login)&password=\(password)"
            AF.request(url, method: .get).validate().responseJSON { response in
                switch response.result {
                case .success(let value):
                    let json = JSON(value)
                    self.alertControllers(title: "Success", description: "Successful authorization")
                    print("JSON: \(json)")
                case .failure(let error):
                    print(error)
                    self.alertControllers(title: "Error", description: "User not found")
                }
            }
        }
        else {
            alertControllers(title: "Errors", description: "Login or password are missing ")
        }
    }
    
    func alertControllers(title: String, description: String) {
        passwordTextField.text! = ""
        let alert = UIAlertController(title: title, message: description, preferredStyle: .alert)
        let closeAction = UIAlertAction(title: "Close", style: .cancel, handler: nil)
        alert.addAction(closeAction)
        present(alert, animated: true, completion: nil)
    }

    @IBAction func goBackAction(_ sender: Any) {
        if loginTextField.text!.isEmpty || passwordTextField.text!.isEmpty{
            performSegue(withIdentifier: "openMainView", sender: self)
        }
        else{
            alertControllers(title: "Error", description: "Fields should be empty")
        }
    }
}
